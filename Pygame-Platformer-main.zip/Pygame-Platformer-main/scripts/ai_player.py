import math
import pygame

class AIPlayer:
    def __init__(self, game):
        self.game = game
        self.reaction_time = 10  # frames to wait before reacting to threats
        self.threat_memory = []  # remember projectile positions
        self.last_action_time = 0
        self.path = []  # for pathfinding
        self.target_enemy = None
        self.safe_platform = None
        self.last_pos = None
        self.stuck_timer = 0
        self.last_jump_time = 0
        self.last_dash_time = 0
        self.debug = True  # Enable debug printing
        self.current_target = None
        self.target_lock_time = 0
        self.target_lock_duration = 2000  # Lock onto current target for 2 seconds
        self.periodic_jump_timer = 0  # New timer for periodic jumps
        
    def get_nearest_enemy(self):
        current_time = pygame.time.get_ticks()
        
        # Keep current target if lock time hasn't expired and target still exists
        if (self.current_target and 
            current_time - self.target_lock_time < self.target_lock_duration and 
            self.current_target in self.game.enemies):
            
            player_pos = self.game.player.rect().center
            dist = math.sqrt((player_pos[0] - self.current_target.pos[0])**2 + 
                           (player_pos[1] - self.current_target.pos[1])**2)
            height_diff = abs(player_pos[1] - self.current_target.pos[1])
            
            # Release target lock if height difference becomes too large
            if height_diff > 60:
                if self.debug:
                    print(f"Releasing target lock - height difference too large: {height_diff}")
                self.current_target = None
            else:
                if self.debug:
                    print(f"Pursuing locked target at distance: {dist}, height diff: {height_diff}")
                return self.current_target, dist

        if not self.game.enemies:
            if self.debug:
                print("No enemies found")
            return None, float('inf')
        
        player_pos = self.game.player.rect().center
        nearest = None
        min_score = float('inf')  # Lower score is better
        
        for enemy in self.game.enemies:
            dist = math.sqrt((player_pos[0] - enemy.pos[0])**2 + 
                           (player_pos[1] - enemy.pos[1])**2)
            height_diff = abs(player_pos[1] - enemy.pos[1])
            
            # Score based on both distance and height difference
            # Heavily penalize height differences over 60 pixels
            height_penalty = height_diff * 2 if height_diff <= 60 else height_diff * 10
            score = dist + height_penalty
            
            if score < min_score:
                min_score = score
                nearest = enemy
        
        # Only lock onto target if height difference is acceptable
        if nearest:
            height_diff = abs(player_pos[1] - nearest.pos[1])
            if height_diff <= 60:
                self.current_target = nearest
                self.target_lock_time = current_time
                if self.debug:
                    print(f"New target acquired! Distance: {min_score}, Height diff: {height_diff}")
            else:
                if self.debug:
                    print(f"Target too far in height ({height_diff}px), seeking better target")
                return None, float('inf')
        
        return nearest, min_score

    def is_position_safe(self, pos):
        # Check if position has ground below
        ground_check = self.game.tilemap.solid_check((pos[0], pos[1] + 32))
        if not ground_check:
            return False
            
        # Check for projectiles near position
        for proj in self.game.projectiles:
            proj_pos = proj[0]
            dist = math.sqrt((pos[0] - proj_pos[0])**2 + (pos[1] - proj_pos[1])**2)
            if dist < 40:  # danger zone
                return False
                
        return True

    def find_safe_platform(self):
        player_pos = self.game.player.rect().center
        search_radius = 100
        
        # Sample points in a grid pattern
        for x in range(player_pos[0] - search_radius, player_pos[0] + search_radius, 32):
            for y in range(player_pos[1] - search_radius, player_pos[1] + search_radius, 32):
                if self.is_position_safe((x, y)):
                    return (x, y)
                    
        return None

    def should_dodge(self):
        player_rect = self.game.player.rect()
        dodge_radius = 50  # Circular radius for dodge detection
        
        for proj in self.game.projectiles:
            proj_pos = proj[0]
            proj_dir = proj[1]
            
            # Calculate distances
            dist_x = proj_pos[0] - player_rect.centerx
            dist_y = proj_pos[1] - player_rect.centery
            
            # Calculate direct distance (radius)
            direct_distance = math.sqrt(dist_x**2 + dist_y**2)
            
            # Predict if projectile will hit
            if (proj_dir > 0 and dist_x > 0) or (proj_dir < 0 and dist_x < 0):
                time_to_impact = abs(dist_x / proj_dir)
                
                # If projectile is within dodge radius and approaching
                if direct_distance < dodge_radius and time_to_impact < 45:
                    # Calculate angle of approach (in degrees)
                    angle = math.degrees(math.atan2(abs(dist_y), abs(dist_x)))
                    
                    if self.debug:
                        print(f"Bullet detected! Distance: {direct_distance:.1f}, Angle: {angle:.1f}°, Time: {time_to_impact:.1f}")
                    
                    # Horizontal approach (angle < 30 degrees) - needs immediate jump
                    if angle < 30:
                        if self.debug:
                            print("Direct horizontal threat - Jump needed!")
                        return True, proj_dir, time_to_impact, True
                    # Diagonal approach - regular dodge
                    else:
                        if self.debug:
                            print("Diagonal threat - Regular dodge")
                        return True, proj_dir, time_to_impact, False
                    
        return False, 0, 0, False

    def is_platform_above(self):
        player = self.game.player
        check_height = 64  # Check up to 64 pixels above
        check_width = 32   # Check 32 pixels wide
        
        # Check for platform above
        for y_offset in range(16, check_height, 16):
            left_point = (player.pos[0] - check_width // 2, player.pos[1] - y_offset)
            right_point = (player.pos[0] + check_width // 2, player.pos[1] - y_offset)
            
            if (self.game.tilemap.solid_check(left_point) or 
                self.game.tilemap.solid_check(right_point)):
                if self.debug:
                    print(f"Found platform {y_offset}px above")
                return True, y_offset
        return False, 0

    def is_near_edge(self):
        player = self.game.player
        check_distance = 32  # Check 32 pixels ahead
        check_depth = 48    # Check 48 pixels down for ground
        
        # Check both left and right sides
        left_edge = False
        right_edge = False
        
        # Check left edge
        left_ground = self.game.tilemap.solid_check((player.pos[0] - check_distance, player.pos[1] + check_depth))
        if not left_ground and player.collisions['down']:
            left_edge = True
            
        # Check right edge
        right_ground = self.game.tilemap.solid_check((player.pos[0] + check_distance, player.pos[1] + check_depth))
        if not right_ground and player.collisions['down']:
            right_edge = True
            
        if left_edge or right_edge:
            if self.debug:
                print(f"Edge detected! Left: {left_edge}, Right: {right_edge}")
            return True, left_edge, right_edge
            
        return False, False, False

    def check_platform_below(self):
        player = self.game.player
        check_depth = 128  # Check up to 128 pixels below
        check_width = 32   # Check 32 pixels wide
        
        # Check for platform below
        for y_offset in range(32, check_depth, 16):
            left_point = (player.pos[0] - check_width // 2, player.pos[1] + y_offset)
            right_point = (player.pos[0] + check_width // 2, player.pos[1] + y_offset)
            
            if (self.game.tilemap.solid_check(left_point) or 
                self.game.tilemap.solid_check(right_point)):
                if self.debug:
                    print(f"Found platform {y_offset}px below")
                return True, y_offset
        if self.debug:
            print("No platform detected below!")
        return False, 0

    def update(self):
        current_time = pygame.time.get_ticks()
        player = self.game.player
        
        # Reset movement
        self.game.movement = [False, False]
        
        # Check for edges (HIGHEST PRIORITY)
        near_edge, left_edge, right_edge = self.is_near_edge()
        if near_edge and player.collisions['down']:
            if self.debug:
                print("Near edge - taking evasive action!")
            
            # If moving towards the edge, jump to avoid falling
            if (left_edge and self.game.movement[0]) or (right_edge and self.game.movement[1]):
                if current_time - self.last_jump_time > 500:
                    if self.debug:
                        print("Edge detected - Jumping to safety!")
                    player.jump()
                    self.last_jump_time = current_time
            
            # Move away from the edge
            if left_edge:
                self.game.movement[1] = True  # Move right
            elif right_edge:
                self.game.movement[0] = True  # Move left
        
        # Increment periodic jump timer
        self.periodic_jump_timer += 1
        
        # Periodic jump every 3 seconds (180 frames) if on ground and not dodging
        if self.periodic_jump_timer >= 180 and player.collisions['down']:
            if current_time - self.last_jump_time > 500:
                if self.debug:
                    print("Performing periodic jump to avoid getting stuck!")
                player.jump()
                self.last_jump_time = current_time
            self.periodic_jump_timer = 0
        
        # Handle dodging projectiles (HIGHEST PRIORITY)
        should_dodge, proj_dir, time_to_impact, same_level = self.should_dodge()
        if should_dodge:
            if self.debug:
                print("DODGE MODE ACTIVATED!")
            
            # Always try to jump if projectile is at same height level
            if same_level and player.collisions['down'] and current_time - self.last_jump_time > 300:
                if self.debug:
                    print("Same level bullet detected - Jumping to dodge!")
                player.jump()
                self.last_jump_time = current_time
            
            # Emergency dash if projectile is very close
            if time_to_impact < 20 and current_time - self.last_dash_time > 500:
                if self.debug:
                    print("Emergency dash dodge!")
                player.dash()
                self.last_dash_time = current_time
                # Move away from projectile
                if proj_dir > 0:
                    self.game.movement[0] = True
                else:
                    self.game.movement[1] = True
                return
            
            # Regular jump dodge for non-same-level threats
            if not same_level and player.collisions['down'] and current_time - self.last_jump_time > 300:
                if self.debug:
                    print("Jump dodge!")
                player.jump()
                self.last_jump_time = current_time
            
            # Move away from projectile
            if proj_dir > 0:
                self.game.movement[0] = True  # Move left
            else:
                self.game.movement[1] = True  # Move right
            return  # Focus on dodging
        
        # Get nearest enemy and distance
        nearest_enemy, distance = self.get_nearest_enemy()
        
        # Attack nearest enemy (Secondary priority)
        if nearest_enemy:
            if self.debug:
                print(f"Targeting enemy at distance {distance}")
            dist_x = nearest_enemy.pos[0] - player.pos[0]
            dist_y = nearest_enemy.pos[1] - player.pos[1]
            
            # Only dash attack if no projectiles are nearby
            if abs(dist_x) < 50 and abs(dist_y) < 30 and not self.game.projectiles:
                if current_time - self.last_dash_time > 800:
                    if self.debug:
                        print("Safe to dash attack!")
                    player.dash()
                    self.last_dash_time = current_time
                    return
            
            # Position for attack
            if abs(dist_x) > 20:
                if dist_x > 0:
                    self.game.movement[1] = True
                    if self.debug:
                        print("Moving right towards enemy")
                else:
                    self.game.movement[0] = True
                    if self.debug:
                        print("Moving left towards enemy")
            
            # Jump if enemy is above or if stuck
            if player.collisions['down'] and current_time - self.last_jump_time > 500:
                if dist_y < -20 or self.stuck_timer > 30:
                    player.jump()
                    self.last_jump_time = current_time
                    if self.debug:
                        print("Jumping towards enemy")
        
        # Wall slide handling
        if player.wall_slide:
            if self.debug:
                print("Wall sliding, attempting recovery")
            if player.collisions['right']:
                self.game.movement[0] = True
            else:
                self.game.movement[1] = True
            
            if current_time - self.last_jump_time > 500:
                player.jump()
                self.last_jump_time = current_time
        
        # Stuck detection
        if self.last_pos == player.pos:
            self.stuck_timer += 1
            if self.stuck_timer > 30:
                if self.debug:
                    print("Stuck detected! Checking for platform above...")
                platform_above, height = self.is_platform_above()
                
                if platform_above:
                    if self.debug:
                        print(f"Platform detected at height {height}, attempting to jump!")
                    if current_time - self.last_jump_time > 500:
                        player.jump()
                        self.last_jump_time = current_time
                        # Move slightly in the direction of more space
                        left_space = not self.game.tilemap.solid_check((player.pos[0] - 32, player.pos[1]))
                        right_space = not self.game.tilemap.solid_check((player.pos[0] + 32, player.pos[1]))
                        if left_space and not right_space:
                            self.game.movement[0] = True
                        elif right_space and not left_space:
                            self.game.movement[1] = True
                else:
                    if self.debug:
                        print("No platform above, trying to move horizontally")
                    # Alternate movement direction when stuck
                    if self.stuck_timer % 60 < 30:
                        self.game.movement[1] = True
                    else:
                        self.game.movement[0] = True
        else:
            self.stuck_timer = 0
        
        # Update position memory
        self.last_pos = player.pos.copy()
        
        # Prevent falling and handle double jumps
        if not player.collisions['down'] and player.air_time > 30:
            platform_below, depth = self.check_platform_below()
            
            if not platform_below:
                if self.debug:
                    print("No platform below - attempting double jump!")
                if current_time - self.last_jump_time > 500 and not player.wall_slide:
                    if self.debug:
                        print("Performing double jump for recovery!")
                    player.jump()
                    self.last_jump_time = current_time
            
            if self.debug:
                print("Preventing fall!")
            if player.wall_slide:
                if current_time - self.last_jump_time > 500:
                    player.jump()
                    self.last_jump_time = current_time
            else:
                if not player.collisions['right']:
                    self.game.movement[1] = True
                else:
                    self.game.movement[0] = True 